import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import com.mysql.jdbc.Statement;

public class readFile {

    public static void main(String[] args) throws ClassNotFoundException, IllegalAccessException, InstantiationException, SQLException {
    	String[] fileData;
        String csvFile = "C:\\Users\\Nimisha\\Downloads\\TimesheetRawData.csv";
        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = ",";
        //insertRow(5,"Rachel","rach");
        String date, fname,lname,project,hours;
        
		
        
        try {
        	
            br = new BufferedReader(new FileReader(csvFile));
            while ((line = br.readLine()) != null) {

                // use comma as separator
                 fileData = line.split(cvsSplitBy);
                 
                 date=fileData[0];
                 fname=fileData[1];
                 lname=fileData[2];
                 project=fileData[3];
                 hours=fileData[5];
                 insertFileDataRow(date,fname,lname,project,hours);
                 System.out.println(" "+date+" "+fname+" "+lname+" "+project+" "+hours);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    public static int insertRow(int id,String name , String pass) throws ClassNotFoundException,IllegalAccessException,InstantiationException,SQLException{
    	Connection c = dbcon.getConnection();
    	Statement st = (Statement) c.createStatement();
		String sql ="INSERT INTO user  VALUES ('"+id+"', '"+name+"', '"+pass+"')";
		int res =st.executeUpdate(sql);
		c.close();
		return res;
	}  
    public static int insertFileDataRow(String date ,String fName , String lName, String project, String hours) throws ClassNotFoundException,IllegalAccessException,InstantiationException,SQLException{
    	Connection c = dbcon.getConnection();
    	Statement st = (Statement) c.createStatement();
		String sql ="INSERT INTO fileData  VALUES ('0','"+date+"', '"+fName+"', '"+lName+"','"+project+"', '"+hours+"')";
		int res =st.executeUpdate(sql);
		c.close();
		return res;
	}  
       
         
		
    
		
        


}
