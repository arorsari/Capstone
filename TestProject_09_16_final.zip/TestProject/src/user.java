
public class user {
	public String userid;
	public String userpass;
	
	   public String getUserid() 
	   {
		return userid;
	}
	public void setUserid(String userid) 
	{
		this.userid = userid;
	}
	
	public String getUserpass() 
	{
		return userpass;
	}
	public void setUserpass(String userpass) 
	{
		this.userpass = userpass;
	}
	
	 public String toString() {
		 
		 return "UserId - " + userid +" UserPass - "+userpass+"\n";
	 }
	    
	    
	}


