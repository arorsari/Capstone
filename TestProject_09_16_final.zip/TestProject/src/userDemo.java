import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Statement;
 

public class userDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		//BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("List all users:");
         
        //String userId;
        
        try {
        	//userId=br.readLine();
            //userId = String.parseString(br.readLine());
            userDemo demo = new userDemo();
            user usr = demo.getUser();
            System.out.println(usr);           
        } 
        catch (NumberFormatException e) {
            e.printStackTrace();
        }       
    }
 
    public user getUser()  {      
        ResultSet rs = null;
        Connection connection = null;
        Statement statement = null; 
         
        user usr = null;
        String query = "SELECT * FROM user";
        try {           
            connection = dbcon.getConnection();
            statement = (Statement) connection.createStatement();

           rs = statement.executeQuery(query);
             
            while (rs.next()) {
                usr = new user();
                usr.setUserid(rs.getString("userid"));
                usr.setUserpass(rs.getString("password"));
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return usr;
    }
	}

