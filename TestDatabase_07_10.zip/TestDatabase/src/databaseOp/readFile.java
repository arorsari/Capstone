package databaseOp;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import com.mysql.jdbc.Statement;

public class readFile {

   
   

	public void rFile(String path) throws ClassNotFoundException, IllegalAccessException, InstantiationException, SQLException
    	{
    	String[] fileData;
        String csvFile =path;
        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = ",";
        String date, fname,lname,project,hours;
        
		
        
        try {
        	
            br = new BufferedReader(new FileReader(csvFile));
            while ((line = br.readLine()) != null) {

                // use comma as separator
                 fileData = line.split(cvsSplitBy);
                 
                 date=fileData[0];
                 fname=fileData[1];
                 lname=fileData[2];
                 project=fileData[3];
                 hours=fileData[5];
                 DatabaseOperations dbop=new DatabaseOperations();
                 dbop.insertFileDataRow(date, fname, lname, project, hours);
                System.out.println("Printing from readfile/rfile "+date+" "+fname+" "+lname+" "+project+" "+hours);
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
            }

        } 
        catch (FileNotFoundException e) 
        {
            e.printStackTrace();
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        } 
        finally 
        {
            if (br != null) 
            {
                try 
                {
                    br.close();
                } catch (IOException e) 
                {
                    e.printStackTrace();
                }
            }
        }
    	}
    

    
       
     
		
    
		
        


}
