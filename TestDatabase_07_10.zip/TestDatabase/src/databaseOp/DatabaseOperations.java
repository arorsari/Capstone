package databaseOp;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JDialog;
import javax.swing.JOptionPane;

import com.mysql.jdbc.Statement;




import model.Resource;
import model.Client;
import model.FileData;
import model.Project;
import util.Database;

public class DatabaseOperations 
{
	 Connection connection;
	 PreparedStatement preparedStatement;
	 
    public DatabaseOperations() {
        connection = Database.getConnection();
    }
  
	public Resource getResourceById(String resourceId) 
	{
		// TODO Auto-generated method stub
		System.out.print(resourceId+ " From GetResourceId Method");
		Resource res=new Resource();
		try {
            preparedStatement = this.connection.prepareStatement("select * from resource where fname=?");
            System.out.println(" prepared "+preparedStatement.toString());
            preparedStatement.setString(1, resourceId);
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
            	res.setFname(rs.getString("fname"));
            	res.setLname(rs.getString("lname"));
            	res.setEmail(rs.getString("email"));
            	res.setDepartment(rs.getString("department"));
            	res.setBillRate(rs.getString("billRate"));
            	res.setCostRate(rs.getString("costRate"));
                res.setPermissions(rs.getString("permission"));             
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }	
		return res;
	}
	public List<Resource> getAllResource() 
	{
	        List<Resource> reses = new ArrayList<Resource>();
	        try {
	            Statement statement = (Statement) connection.createStatement();
	            ResultSet rs = statement.executeQuery("select * from resource");
	            while (rs.next()) {
	                Resource res = new Resource();
	            	res.setFname(rs.getString("fname"));
	            	res.setLname(rs.getString("lname"));
	            	res.setEmail(rs.getString("email"));
	            	res.setDepartment(rs.getString("department"));
	            	res.setBillRate(rs.getString("billRate"));
	            	res.setCostRate(rs.getString("costRate"));
	                res.setPermissions(rs.getString("permission"));
	                reses.add(res);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }	 
	        return reses;
	    }
	
	public int insertFileDataRow(String date ,String fName , String lName, String project, String hours) throws ClassNotFoundException,IllegalAccessException,InstantiationException,SQLException{
		Connection c = Database.getConnection();
    	Statement st = (Statement) c.createStatement();
		String sql ="INSERT INTO fileData  VALUES ('0','"+date+"', '"+fName+"', '"+lName+"','"+project+"', '"+hours+"')";
		int res =st.executeUpdate(sql);
		c.close();
		return res;
	}
	public List<FileData> getAllFileData() 
	{
		// TODO Auto-generated method stub
		  List<FileData> reses = new ArrayList<FileData>();
	        try {
	            Statement statement = (Statement) connection.createStatement();
	            ResultSet rs = statement.executeQuery("select * from filedata");
	            while (rs.next()) {
	                FileData res = new FileData();
	                res.setDate(rs.getString("date"));
	            	res.setFname(rs.getString("fname"));
	            	res.setLname(rs.getString("lname"));
	            	res.setProject(rs.getString("project"));
	            	res.setHoure(rs.getString("hours"));
	                reses.add(res);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        System.out.println("From getAllFileData "+reses);
	        return reses;
	    }
	public List<Project> getAllProjects() {
		// TODO Auto-generated method stub
		List<Project> reses = new ArrayList<Project>();
        try {
            Statement statement = (Statement) connection.createStatement();
            ResultSet rs = statement.executeQuery("select * from project");
            while (rs.next()) {
                Project res = new Project();
                res.setClient(rs.getString("client"));
        		res.setProjectName(rs.getString("name"));
        		res.setProjectCode(rs.getString("code"));
        		res.setDateStart(rs.getString("sdate"));
        		res.setDateEnd(rs.getString("edate"));
        		res.setNotes(rs.getString("notes"));
        		res.setInvoiceMethod(rs.getString("invoice"));
        		res.setBudget(rs.getString("budget"));
        		res.setPermissions(rs.getString("permissions"));
        		res.setTasks(rs.getString("task"));
        		res.setTeam(rs.getString("team"));
                reses.add(res);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return reses;
	}
	public List<Client> getAllClients() {
		// TODO Auto-generated method stub
		List<Client> reses = new ArrayList<Client>();
        try {
            Statement statement = (Statement) connection.createStatement();
            ResultSet rs = statement.executeQuery("select * from clients");
            while (rs.next()) {
                Client res = new Client();
                res.setClientName(rs.getString("clientname"));
        		res.setAddress(rs.getString("address"));
        		res.setCurrency(rs.getString("currency"));
        		
        		
                reses.add(res);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return reses;
	}
	
	
	public int getNumResourc()  {
		int count = 0;
		try {
            Statement statement = (Statement) connection.createStatement();
            ResultSet rs = statement.executeQuery("select count(*)num from resource");
            while (rs.next()) {
            	count=rs.getInt("num");  
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        System.out.println("From getNumResource "+count);
        return count;
    }
	
	public int getNumProject() {
		int count=0;
		try{
		Statement statement = (Statement) connection.createStatement();
        ResultSet rs = statement.executeQuery("select count(*)num from project");
        while (rs.next()) {
            count=rs.getInt("num");
        }
		}catch(SQLException e) {
            e.printStackTrace();
        }
		System.out.println("From getNumProject "+count);
		return count;
	}

	public int getNumClient()   {
		int count=0;
		try{
		Statement statement = (Statement) connection.createStatement();
        ResultSet rs = statement.executeQuery("select count(*)num from clients");
        while (rs.next()) {
            count=rs.getInt("num");
        }
		}catch(SQLException e) {
            e.printStackTrace();
        }
		System.out.println("From getNumClient "+count);
		return count;
	}

	public void addClient(Client res) {
		// TODO Auto-generated method stub
				try {
		            preparedStatement = connection
		           		.prepareStatement("insert into clients(clientname,address,currency) values (?,?,?)");
		           // Parameters start with 1
		           preparedStatement.setString(1, res.getClientName());
		           preparedStatement.setString(2, res.getAddress());
		           preparedStatement.setString(3, res.getCurrency());
		           
		           preparedStatement.executeUpdate();

		       } catch (SQLException e) {
		           e.printStackTrace();
		       }
			}
	
	public void deleteResource(String email) {

		try {
			String sql = "DELETE FROM resource WHERE email =?";
            PreparedStatement prest = connection.prepareStatement(sql);
            prest.setString(1, email);
            int val = prest.executeUpdate();
            final JDialog dialog = new JDialog();

            dialog.setAlwaysOnTop(true);    

            JOptionPane.showMessageDialog(dialog, "The record has been successfully deleted");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public  void addResource(Resource res) {		
		try {
             preparedStatement = connection
            		.prepareStatement("insert into resource(fname,lname,email,department,billRate,costRate,permission) values (?,?,?,?,?,?,? )");
            // Parameters start with 1
            preparedStatement.setString(1, res.getFname());
            preparedStatement.setString(2, res.getLname());
            preparedStatement.setString(3, res.getEmail());
            preparedStatement.setString(4, res.getDepartment());
            preparedStatement.setString(5, res.getBillRate());
            preparedStatement.setString(6, res.getCostRate());
            preparedStatement.setString(7, res.getPermissions());           
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }		
	}
	public void addProject(Project res) {
		// TODO Auto-generated method stub
		try {
            preparedStatement = connection
           		.prepareStatement("insert into project(client,name,code,sdate,edate,notes,invoice,budget,permissions,task,team) values (?,?,?,?,?,?,?,?,?,?,? )");
           // Parameters start with 1
           preparedStatement.setString(1, res.getClient());
           preparedStatement.setString(2, res.getProjectName());
           preparedStatement.setString(3, res.getProjectCode());
           preparedStatement.setString(4, res.getDateStart());
           preparedStatement.setString(5, res.getDateEnd());
           preparedStatement.setString(6, res.getNotes());
           preparedStatement.setString(7, res.getInvoiceMethod());
           preparedStatement.setString(8, res.getBudget());
           preparedStatement.setString(9, res.getTasks());
           preparedStatement.setString(10, res.getTeam());
           preparedStatement.setString(11, res.getPermissions());
          
           
           preparedStatement.executeUpdate();

       } catch (SQLException e) {
           e.printStackTrace();
       }
	}

}	

	

